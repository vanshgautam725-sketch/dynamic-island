import React, { useState, useRef } from 'react';
import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  Animated,
  SafeAreaView,
  StatusBar,
  ScrollView,
  Image,
  Linking,
  Platform,
  Alert,
} from 'react-native';
import { Ionicons, MaterialCommunityIcons, Feather } from '@expo/vector-icons';
import * as ImagePicker from 'expo-image-picker';

export default function App() {
  // Island State Cycle: 'compact' -> 'charging' -> 'music' -> 'call' -> 'custom_pic'
  const [islandState, setIslandState] = useState('compact');
  const [currentTheme, setCurrentTheme] = useState('glass'); 
  const [customImage, setCustomImage] = useState(null); // User Gallery Photo

  // Spring Physics Animation Values
  const widthAnim = useRef(new Animated.Value(125)).current;
  const heightAnim = useRef(new Animated.Value(38)).current;
  const radiusAnim = useRef(new Animated.Value(22)).current;

  // 1. SYSTEM OVERLAY PERMISSION (Settings kholne ka code)
  const openOverlaySettings = () => {
    if (Platform.OS === 'android') {
      Linking.openSettings();
    } else {
      Alert.alert('Info', 'Yeh permission Android devices ke liye hai.');
    }
  };

  // 2. USER GALLERY PHOTO PICKER (Goku/Naruto/Custom image chunne ka code)
  const pickCustomImage = async () => {
    try {
      const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (status !== 'granted') {
        Alert.alert('Permission Chahiye', 'Gallery se photo lene ke liye permission allow karein!');
        return;
      }

      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: true,
        aspect: [1, 1],
        quality: 1,
      });

      if (!result.canceled && result.assets && result.assets.length > 0) {
        setCustomImage(result.assets[0].uri);
        Alert.alert('Success! 🎉', 'Custom photo Dynamic Island mein set ho gayi!');
        triggerAnimation('custom_pic', 340, 90, 40);
      }
    } catch (e) {
      Alert.alert('Error', 'Image select nahi ho paayi.');
    }
  };

  // Animation Trigger
  const triggerAnimation = (nextState, targetWidth, targetHeight, targetRadius) => {
    setIslandState(nextState);
    Animated.parallel([
      Animated.spring(widthAnim, {
        toValue: targetWidth,
        friction: 6.5,
        tension: 50,
        useNativeDriver: false,
      }),
      Animated.spring(heightAnim, {
        toValue: targetHeight,
        friction: 6.5,
        tension: 50,
        useNativeDriver: false,
      }),
      Animated.spring(radiusAnim, {
        toValue: targetRadius,
        friction: 6.5,
        tension: 50,
        useNativeDriver: false,
      }),
    ]).start();
  };

  // Touch on Island directly cycles through modes
  const handleIslandTap = () => {
    if (islandState === 'compact') {
      triggerAnimation('charging', 330, 75, 36);
    } else if (islandState === 'charging') {
      triggerAnimation('music', 345, 88, 40);
    } else if (islandState === 'music') {
      triggerAnimation('call', 355, 175, 44);
    } else if (islandState === 'call' && customImage) {
      triggerAnimation('custom_pic', 340, 90, 40);
    } else {
      triggerAnimation('compact', 125, 38, 22);
    }
  };

  // THEMES CONFIGURATION
  const themes = {
    glass: {
      name: 'Liquid Glass',
      bg: 'rgba(255, 255, 255, 0.12)',
      border: 'rgba(255, 255, 255, 0.4)',
      glow: '#FFFFFF',
    },
    rainbow: {
      name: 'AI Rainbow Glow',
      bg: 'rgba(10, 10, 20, 0.95)',
      border: '#EC4899',
      glow: '#F43F5E',
    },
    purple: {
      name: 'Cyber Purple',
      bg: 'rgba(26, 11, 46, 0.96)',
      border: '#A855F7',
      glow: '#9333EA',
    },
    blue: {
      name: 'Electric Cyan',
      bg: 'rgba(8, 47, 73, 0.96)',
      border: '#38BDF8',
      glow: '#0284C7',
    },
    black: {
      name: 'Stealth Black',
      bg: '#000000',
      border: '#1E293B',
      glow: '#0F172A',
    },
  };

  const activeTheme = themes[currentTheme];

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="light-content" />

      {/* TOP NOTCH AREA / DYNAMIC ISLAND */}
      <View style={styles.topArea}>
        <TouchableOpacity activeOpacity={0.88} onPress={handleIslandTap}>
          <Animated.View
            style={[
              styles.island,
              {
                width: widthAnim,
                height: heightAnim,
                borderRadius: radiusAnim,
                backgroundColor: activeTheme.bg,
                borderColor: activeTheme.border,
                shadowColor: activeTheme.glow,
              },
            ]}
          >
            {/* 1. COMPACT PILL */}
            {islandState === 'compact' && (
              <View style={styles.compactRow}>
                {customImage ? (
                  <Image source={{ uri: customImage }} style={styles.miniAvatar} />
                ) : (
                  <View style={styles.cameraLens} />
                )}
                <View style={styles.indicatorLight} />
              </View>
            )}

            {/* 2. CHARGING STATE */}
            {islandState === 'charging' && (
              <View style={styles.notifRow}>
                <View style={styles.batteryIconCircle}>
                  <Ionicons name="flash" size={20} color="#FBBF24" />
                </View>
                <View style={styles.notifDetails}>
                  <Text style={styles.notifTitle}>Super Turbo Charge</Text>
                  <Text style={styles.notifSub}>88% • 15 min to full</Text>
                </View>
                <Text style={styles.chargePercent}>88%</Text>
              </View>
            )}

            {/* 3. MUSIC STATE */}
            {islandState === 'music' && (
              <View style={styles.musicRow}>
                <View style={styles.musicArtwork}>
                  <Ionicons name="musical-notes" size={20} color="#FFF" />
                </View>
                <View style={styles.musicMeta}>
                  <Text style={styles.songName} numberOfLines={1}>
                    Starboy • Daft Punk
                  </Text>
                  <Text style={styles.artistName}>Veletify Hi-Fi Audio</Text>
                </View>
                <MaterialCommunityIcons name="waveform" size={30} color="#38BDF8" />
              </View>
            )}

            {/* 4. CALL STATE */}
            {islandState === 'call' && (
              <View style={styles.callCard}>
                <View style={styles.callTop}>
                  <View style={styles.callerImage}>
                    <Text style={styles.avatarLetter}>V</Text>
                  </View>
                  <View style={styles.callMeta}>
                    <Text style={styles.callerHeading}>Sister 💖</Text>
                    <Text style={styles.callSub}>Ghaziabad • Mobile</Text>
                  </View>
                  <View style={styles.liveCallBadge}>
                    <Text style={styles.liveBadgeText}>00:32</Text>
                  </View>
                </View>
                <View style={styles.callBtnRow}>
                  <View style={[styles.circleAction, styles.declineCircle]}>
                    <Feather name="phone-off" size={22} color="#FFF" />
                  </View>
                  <View style={[styles.circleAction, styles.acceptCircle]}>
                    <Feather name="phone" size={22} color="#FFF" />
                  </View>
                </View>
              </View>
            )}

            {/* 5. CUSTOM USER GALLERY IMAGE STATE */}
            {islandState === 'custom_pic' && (
              <View style={styles.customRow}>
                {customImage && (
                  <Image source={{ uri: customImage }} style={styles.customBigImg} />
                )}
                <View style={styles.customMeta}>
                  <Text style={styles.customTitle}>Custom Theme Active</Text>
                  <Text style={styles.customSub}>Gallery Avatar Loaded</Text>
                </View>
                <Ionicons name="checkmark-circle" size={24} color="#10B981" />
              </View>
            )}
          </Animated.View>
        </TouchableOpacity>

        <Text style={styles.hintTag}>👆 Island par TAP karo switch karne ke liye</Text>
      </View>

      {/* DASHBOARD / PERMISSION CONTROLS */}
      <View style={styles.controlsArea}>
        <View style={styles.actionCard}>
          <Text style={styles.actionHeader}>SYSTEM PERMISSIONS & ASSETS</Text>

          {/* BUTTON 1: OVERLAY PERMISSION */}
          <TouchableOpacity style={styles.permissionBtn} onPress={openOverlaySettings}>
            <Ionicons name="settings-outline" size={20} color="#38BDF8" />
            <Text style={styles.permissionBtnText}>Enable Display Over Other Apps</Text>
          </TouchableOpacity>

          {/* BUTTON 2: PICK CUSTOM GALLERY PHOTO */}
          <TouchableOpacity style={styles.galleryBtn} onPress={pickCustomImage}>
            <Ionicons name="image-outline" size={20} color="#FFF" />
            <Text style={styles.galleryBtnText}>Pick Custom Photo / Anime Avatar</Text>
          </TouchableOpacity>
        </View>

        {/* THEMES ROW */}
        <Text style={styles.themeTitle}>SELECT LUXURY THEME:</Text>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.themeScroll}>
          {Object.keys(themes).map((key) => {
            const t = themes[key];
            const isSelected = currentTheme === key;
            return (
              <TouchableOpacity
                key={key}
                style={[
                  styles.themeChip,
                  { borderColor: isSelected ? t.border : '#1E293B' },
                  isSelected && styles.selectedChip,
                ]}
                onPress={() => setCurrentTheme(key)}
              >
                <View style={[styles.chipDot, { backgroundColor: t.border }]} />
                <Text style={[styles.chipText, isSelected && { color: '#FFF', fontWeight: 'bold' }]}>
                  {t.name}
                </Text>
              </TouchableOpacity>
            );
          })}
        </ScrollView>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#07090E',
  },
  topArea: {
    flex: 1,
    alignItems: 'center',
    paddingTop: 18,
  },
  island: {
    borderWidth: 1.5,
    overflow: 'hidden',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.6,
    shadowRadius: 16,
    elevation: 12,
  },
  compactRow: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
  },
  cameraLens: {
    width: 12,
    height: 12,
    borderRadius: 6,
    backgroundColor: '#000',
    borderWidth: 1,
    borderColor: '#334155',
  },
  miniAvatar: {
    width: 22,
    height: 22,
    borderRadius: 11,
  },
  indicatorLight: {
    width: 9,
    height: 9,
    borderRadius: 5,
    backgroundColor: '#10B981',
  },
  notifRow: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
  },
  batteryIconCircle: {
    width: 38,
    height: 38,
    borderRadius: 19,
    backgroundColor: 'rgba(251, 191, 36, 0.15)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  notifDetails: {
    flex: 1,
    marginLeft: 12,
  },
  notifTitle: {
    color: '#FFF',
    fontSize: 13,
    fontWeight: '700',
  },
  notifSub: {
    color: '#94A3B8',
    fontSize: 11,
    marginTop: 1,
  },
  chargePercent: {
    color: '#FBBF24',
    fontSize: 16,
    fontWeight: '900',
  },
  musicRow: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
  },
  musicArtwork: {
    width: 44,
    height: 44,
    borderRadius: 14,
    backgroundColor: '#EC4899',
    alignItems: 'center',
    justifyContent: 'center',
  },
  musicMeta: {
    flex: 1,
    marginLeft: 12,
  },
  songName: {
    color: '#FFF',
    fontSize: 14,
    fontWeight: '700',
  },
  artistName: {
    color: '#94A3B8',
    fontSize: 11,
    marginTop: 2,
  },
  callCard: {
    flex: 1,
    padding: 18,
    justifyContent: 'space-between',
  },
  callTop: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  callerImage: {
    width: 46,
    height: 46,
    borderRadius: 23,
    backgroundColor: '#8B5CF6',
    alignItems: 'center',
    justifyContent: 'center',
  },
  avatarLetter: {
    color: '#FFF',
    fontSize: 20,
    fontWeight: 'bold',
  },
  callMeta: {
    flex: 1,
    marginLeft: 12,
  },
  callerHeading: {
    color: '#FFF',
    fontSize: 16,
    fontWeight: '700',
  },
  callSub: {
    color: '#94A3B8',
    fontSize: 11,
    marginTop: 2,
  },
  liveCallBadge: {
    backgroundColor: 'rgba(16, 185, 129, 0.2)',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: '#10B981',
  },
  liveBadgeText: {
    color: '#10B981',
    fontWeight: '700',
    fontSize: 12,
  },
  callBtnRow: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginTop: 10,
  },
  circleAction: {
    width: 50,
    height: 50,
    borderRadius: 25,
    alignItems: 'center',
    justifyContent: 'center',
  },
  declineCircle: {
    backgroundColor: '#EF4444',
  },
  acceptCircle: {
    backgroundColor: '#10B981',
  },
  customRow: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
  },
  customBigImg: {
    width: 50,
    height: 50,
    borderRadius: 25,
    borderWidth: 1.5,
    borderColor: '#38BDF8',
  },
  customMeta: {
    flex: 1,
    marginLeft: 14,
  },
  customTitle: {
    color: '#FFF',
    fontSize: 14,
    fontWeight: '700',
  },
  customSub: {
    color: '#94A3B8',
    fontSize: 11,
    marginTop: 2,
  },
  hintTag: {
    color: '#64748B',
    fontSize: 12,
    marginTop: 15,
  },
  controlsArea: {
    paddingBottom: 25,
    paddingHorizontal: 15,
  },
  actionCard: {
    backgroundColor: '#0F172A',
    borderRadius: 18,
    padding: 16,
    borderWidth: 1,
    borderColor: '#1E293B',
    marginBottom: 18,
  },
  actionHeader: {
    color: '#94A3B8',
    fontSize: 11,
    fontWeight: '800',
    letterSpacing: 1.5,
    marginBottom: 12,
  },
  permissionBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#1E293B',
    paddingVertical: 12,
    paddingHorizontal: 14,
    borderRadius: 12,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: '#334155',
  },
  permissionBtnText: {
    color: '#38BDF8',
    fontSize: 13,
    fontWeight: '600',
    marginLeft: 10,
  },
  galleryBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#2563EB',
    paddingVertical: 12,
    paddingHorizontal: 14,
    borderRadius: 12,
  },
  galleryBtnText: {
    color: '#FFF',
    fontSize: 13,
    fontWeight: '700',
    marginLeft: 10,
  },
  themeTitle: {
    color: '#94A3B8',
    fontSize: 11,
    fontWeight: '800',
    letterSpacing: 1.5,
    marginBottom: 10,
    marginLeft: 4,
  },
  themeScroll: {
    flexDirection: 'row',
  },
  themeChip: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#0F172A',
    borderWidth: 1.5,
    paddingVertical: 10,
    paddingHorizontal: 14,
    borderRadius: 25,
    marginRight: 10,
  },
  selectedChip: {
    backgroundColor: '#1E293B',
  },
  chipDot: {
    width: 10,
    height: 10,
    borderRadius: 5,
    marginRight: 8,
  },
  chipText: {
    color: '#94A3B8',
    fontSize: 12,
    fontWeight: '600',
  },
});